#include <stdio.h>

#include <string.h>

struct Player {

    char playerName[50];

    int ballScores[12];

    int totalScore;

};

void playGame(struct Player* player) {

    printf("Enter name of the player: ");

    scanf("%s", player->playerName);

    player->totalScore = 0;

    for (int i = 0; i < 12; i++) {

        printf("Enter score for ball %d: ", i + 1);

        scanf("%d", &player->ballScores[i]);

        if (player->ballScores[i] >= 0 && player->ballScores[i] <= 6) {

            player->totalScore += player->ballScores[i];

        }

    }

}

void findWinner(struct Player player1, struct Player player2) {

    if (player1.totalScore > player2.totalScore) {

        printf("%s wins!\n", player1.playerName);

    } else if (player2.totalScore > player1.totalScore) {

        printf("%s wins!\n", player2.playerName);

    } else {

        printf("It's a tie!\n");

    }

}

int main() {
    struct Player player1, player2;

    printf("Player 1:\n");
    playGame(&player1);
    printf("\nPlayer 2:\n");
    playGame(&player2);

    findWinner(player1, player2);

    return 0;
}