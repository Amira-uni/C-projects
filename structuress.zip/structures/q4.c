#include <stdio.h>
#include <stdlib.h>

void handleInputEmployees(int** ratings, int numEmployees, int numPeriods) {
    for (int i = 0; i < numEmployees; i++) {
        printf("Enter ratings for Employee %d:\n", (i + 1));
        for (int j = 0; j < numPeriods; j++) {
            do {
                System.out.print("Rating for period " + (j + 1) + ": ");
                ratings[i][j] = scanner.nextInt();
            } while (ratings[i][j] < 1 || ratings[i][j] > 10);
        }
    }
}

void showPerformance(int** ratings, int numEmployees, int numPeriods) {
    for (int i = 0; i < numEmployees; i++) {
        printf("Employee %d: ", i + 1);
        for (int j = 0; j < numPeriods; j++) {
            printf("%d ", ratings[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int numEmployees, numPeriods;
    printf("Enter number of employees: ");
    scanf("%d", &numEmployees);
    printf("Enter number of evaluation periods: ");
    scanf("%d", &numPeriods);

    int** ratings = malloc(numEmployees * sizeof(int*));
    for (int i = 0; i < numEmployees; i++) {
        ratings[i] = malloc(numPeriods * sizeof(int));
    }

    handleInputEmployees(ratings, numEmployees, numPeriods);
    showPerformance(ratings, numEmployees, numPeriods);

    for (int i = 0; i < numEmployees; i++) {
        free(ratings[i]);
    }
    free(ratings);

    return 0;
}