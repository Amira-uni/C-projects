#include <stdio.h>

struct Employee {

    int employeeCode;

    char employeeName[50];

    int dateOfJoining;

};

void assignValues(struct Employee* e) {

    printf("Enter Employee Code: ");
    scanf("%d", &e->employeeCode);

    printf("Enter Employee Name: ");
    scanf("%s", e->employeeName);

    printf("Enter Date of Joining (YYYYMMDD): ");
    scanf("%d", &e->dateOfJoining);
}

void checkTenure(struct Employee employees[], int n, int currentDate) {

    int count = 0;

    for (int i = 0; i < n; i++) {

        int tenure = (currentDate/10000) - (employees[i].dateOfJoining/10000);

        if (tenure > 3) {
            printf("Employee Code: %d, Name: %s, Tenure: %d years\n", 
                   employees[i].employeeCode, employees[i].employeeName, tenure);
            count++;

}

    }

    printf("Total Employees with Tenure > 3 Years : %d”, count);

}

int main() {

    Emp employees[4];

    for (int i = 0; i < 4; i++) {

        printf(”\nEntering Details For Employee: %d:\n”, i + 1);

        assignValues(&employees[i]);

    }

    int CurrentDate;

    printf("Enter Current Date(YYYYMMDD) :");

    scanf("%d”, CurrentDate);

    checkTenure(employees, 4, CurrentDate);

    return 0;

}

