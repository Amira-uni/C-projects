/*The count of species is entered by the user.
Using a function that passes the limit number as an argument and then next. The limit count can then be used to allocate memory for species using the malloc function with a call to mallocspeciesCount*sizeof(char).
A for loop up to i equals speciesCount is created to allocate memory to each element.
Another for loop checks all the species and prints each of their names one by one.
free, species i frees memory.
The free function is called to release the entire memory.
This free function is called to free everything allocated by malloc.
Memory is allocated for a number of species entered by the user at the end.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    int speciesCount;
    printf("Enter the number of species: ");
    scanf("%d", &speciesCount);

    char** species = malloc(speciesCount * sizeof(char*));
    for (int i = 0; i < speciesCount; i++) {
        species[i] = malloc(50 * sizeof(char));
        printf("Enter species %d name: ", i + 1);
        scanf("%s", species[i]);
    }

    for (int i = 0; i < speciesCount; i++) {
        printf("Species %d: %s\n", i + 1, species[i]);
        free(species[i]);
    }

    free(species);
    return 0;